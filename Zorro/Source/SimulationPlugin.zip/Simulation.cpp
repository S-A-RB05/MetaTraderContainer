// Broker plugin simulator for Zorro ////////////////////////////
#include "stdafx.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	return TRUE;
}

/////////////////////////////////////////////////////////////
#pragma warning(disable : 4996 4244 4312)
#include <time.h>
#include <string>
typedef double DATE;
#include "..\include\trading.h" // adapt to the Zorro include directory
#define DLLFUNC extern "C" __declspec(dllexport)

#define PLUGIN_VERSION	2
#define INITIAL_PRICE	1.0
#define INITIAL_ID		1000
//#define BROKERTRADE

/////////////////////////////////////////////////////////////
// Helper functions
int (__cdecl *BrokerError)(const char *txt) = NULL;
int (__cdecl *BrokerProgress)(const int percent) = NULL;

void showMsg(const char* text,const char *detail = NULL)
{
	if(!BrokerError) return;
	if(!detail) detail = "";
	static char msg[1024];
	sprintf_s(msg,"%s %s",text,detail);
	BrokerError(msg);
}

double randomPrice()
{
	static double Price = INITIAL_PRICE;
	return Price += (0.0002*INITIAL_PRICE*(rand()-RAND_MAX/2))/RAND_MAX;
}

static char gSymbol[256] = "";	// by SET_SYMBOL
static int gOrderType = 0;	// last order type, FOK/GTC
static int gAmount = 1;	// last order amount
////////////////////////////////////////////////////////////////
// Plugin functions
DLLFUNC int BrokerOpen(char* Name,FARPROC fpError,FARPROC fpProgress)
{
	if(Name) strcpy_s(Name,32,"Simulator");
	(FARPROC&)BrokerError = fpError;
	(FARPROC&)BrokerProgress = fpProgress;
	return PLUGIN_VERSION;
}

DLLFUNC int BrokerLogin(char* User,char* Pwd,char* Type,char* Account)
{
	if(User) {
		showMsg("Simulator connection");
		return 1;
	} 
	return 0;
}

DLLFUNC int BrokerTime(DATE *pTimeGMT)
{
	return 2;	// broker is online
}

DLLFUNC int BrokerAccount(char* Account,double *pdBalance,double *pdTradeVal,double *pdMarginVal)
{
	double Balance = 10000;
	double TradeVal = 0;
	double MarginVal = 0;

	if(pdBalance && Balance > 0.) *pdBalance = Balance;
	if(pdTradeVal && TradeVal > 0.) *pdTradeVal = TradeVal; 
	if(pdMarginVal && MarginVal > 0.) *pdMarginVal = MarginVal;
	return 1;
}

DLLFUNC int BrokerAsset(char* Asset,double* pPrice,double* pSpread,
	double *pVolume, double *pPip, double *pPipCost, double *pMinAmount,
	double *pMarginCost, double *pRollLong, double *pRollShort)
{
	if(pPrice) *pPrice = randomPrice();
	if(pSpread) *pSpread = 0.0001*randomPrice();
	return 1;
}	

DLLFUNC int BrokerHistory2(char* Asset,DATE tStart,DATE tEnd,int nTickMinutes,int nTicks,T6* ticks)
{
	for(int i=0; i<nTicks; i++) {
		ticks->fOpen = randomPrice();
		ticks->fClose = randomPrice();
		ticks->fHigh = 1.0005*max(ticks->fOpen,ticks->fClose);
		ticks->fLow = 0.9995*min(ticks->fOpen,ticks->fClose);
		ticks->time = tEnd - i*nTickMinutes/1440.;
		ticks++;
	}
	return nTicks;
}


DLLFUNC int BrokerBuy2(char* Asset,int Amount,double StopDist,double Limit,double *pPrice,int *pFill)
{
	static int ID = INITIAL_ID;
	gAmount = abs(Amount);
	if(gOrderType == 0) { // simulate FOK order
		if(pPrice) *pPrice = randomPrice();
		if(pFill) *pFill = gAmount;
	} else if(gOrderType == 2) { // simulate GTC order with partial fill
		if(pPrice) *pPrice = randomPrice();
		gAmount /= 3;
		if(pFill) *pFill = gAmount;
	}
	return ID++;
}

#ifdef BROKERTRADE
DLLFUNC int BrokerTrade(int nTradeID, double *pOpen, double *pClose, double *pCost, double *pProfit)
{
	if(gOrderType == 0) 
		return gAmount;
	else // GTC order - stay partially filled forever
		return gAmount;
}
#endif

DLLFUNC double BrokerCommand(int command,intptr_t parameter)
{
	switch(command) {
		case GET_COMPLIANCE: return 2.;
		case GET_MAXREQUESTS: return 30.;
		case SET_ORDERTYPE: return gOrderType = parameter;
		case SET_SYMBOL: strcpy_s(gSymbol,(char*)parameter); return 1.;
	}
	return 0.;
}
